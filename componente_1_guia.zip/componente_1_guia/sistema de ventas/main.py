from shared.herramientas import (imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar)
from views import ClienteController, ProductoController, VentaController

clientes = ClienteController()
productos = ProductoController()
ventas = VentaController(clientes, productos)

def pausa():
    input('\nPresione enter para continuar...')

def pedir_entero(etiqueta):
    '''devuelve un entero o none si el usuario escribio otra cosa'''
    try:
        return int(input(etiqueta))
    except ValueError:
        return None

def mostrar_resultado(exito, mensaje):
    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)

def mostrar_lista(objetos, vacio = 'no hay registros todavia.'):
    '''sirve para clientes, productos y ventas: cada modelo sabe mostrarse'''
    if not objetos:
        imprimir_info(vacio)
        return
    
    for objeto in objetos:
        print(f'  {objeto}')
    imprimir_info(f'total: {len(objetos)}')
    
def mostrar_detaller(objeto):
    for  clave, valor in objeto.a_diccionario().items():
        print(f'  {str(clave).replace('_', ' ').capitalize():<16}: {valor}')
        
# menu clientes
def crear_cliente():
    datos = {
        'nombre': input('nombre: '),
        'apellido': input('apellido: '),
        'email': input('email: '),
        'telefono': input('telefono: '),
        'ciudad': input('ciudad: ')
    }
    mostrar_resultado(*clientes.crear(datos))
    pausa()
    
def listar_clientes():
    imprimir_titulo('CLIENTES')
    mostrar_lista(clientes.leer(), 'Todavia no hay clientes')
    pausa()
    
def buscar_cliente():
    imprimir_titulo('BUSCAR CLIENTE')
    termino = input('nombre, email, telefono o ciudad: ')
    encontrados = clientes.buscar(termino)
    mostrar_lista(encontrados, f"Ningun cliente coincide con '{termino}'.")
    
def ver_cliente():
    imprimir_titulo('VER CLIENTE POR ID')
    cliente = clientes.obtener(pedir_entero('Id: '))
    if cliente is None:
        imprimir_error('no encontrado')
    else:
        mostrar_detaller(cliente)
    pausa()
    
def actualizar_cliente():
    imprimir_titulo("ACTUALIZAR CLIENTE")
    id_cliente = pedir_entero('Id: ')
    cliente = clientes.obtener(id_cliente)
    if cliente is None:
        imprimir_error('no encontrado')
        return
    
    imprimir_info(f'editando: {cliente.etiqueta()}')
    print('deje en blanco lo que no quiere cambiar')
    
    cambios = {}
    for campo in ('nombre', 'apellido', 'email', 'telefono', 'ciudad'):
        actual = getattr(cliente, campo)
        nuevo = input(f'{campo.capitalize()} [{actual}]: ').strip()
        if nuevo:
            cambios[campo] = nuevo
    
    mostrar_resultado(*clientes.actualizar(id_cliente, cambios))
    pausa()
        

def eliminar_cliente():
    imprimir_titulo('ELIMINAR CLIENTE')
    id_cliente = pedir_entero('Id: ')
    cliente = clientes.obtener(id_cliente)
    if cliente is None:
        imprimir_exito('no encontrado')
        return pausa()
    
    imprimir_info(f'se eliminara: {cliente.etiqueta()}')
    if confirmar('confirma?'):
        mostrar_resultado(*clientes.eliminar(id_cliente))
    else:
        imprimir_info('Operacion cancelada')
    pausa()

def cliente_por_ciudad_ejercicio():
    print('\n diccionario de clientes por pais:')
    diccionario = clientes.cliente_por_ciudad()
    for ciudad, nombres in diccionario.items():
        print(f' - {ciudad}: {str(nombres).replace('[', '').replace(']', '')}')
    pausa()
    
#menu productos
def crear_producto():
    imprimir_titulo('CREAR PRODUCTO')
    datos = {
        'nombre': input('nombre: '),
        'precio': input('precio: '),
        'stock': input('stock: ')
    }  
    mostrar_resultado(*productos.crear(datos))
    pausa()

def listar_productos():
   imprimir_titulo('PRODUCTOS')
   mostrar_lista(productos.leer(), 'Todavia no hay productos')
   pausa()

def buscar_producto():
    imprimir_titulo('BUSCAR PRODUCTO')
    termino = input('Nombre: ')
    mostrar_lista(productos.buscar(termino), 'sin coincidencias')
    pausa()
    
def ver_producto():
    imprimir_titulo('VER PRODUCTO POR ID')
    producto = productos.obtener(pedir_entero('Id: '))
    if producto is None:
        imprimir_error('no encontrado')
    else:
        mostrar_detaller(producto)
        imprimir_info(f'precio con iva: {producto.con_iva(producto.precio):.2f}')
    pausa()
    
def actualizar_producto():
    imprimir_titulo("ACTUALIZAR PRODUCTO")
    id_producto = pedir_entero('Id: ')
    producto = productos.obtener(id_producto)
    if producto is None:
        imprimir_error('No encontrado')
        return pausa()
    
    imprimir_info(f'Editando: {producto.etiqueta()}')
    print('deje en blanco lo que no quiera cambiar.\n')
    
    cambios = {}
    for campo in ('nombre', 'precio', 'stock'):
        actual = getattr(producto, campo)
        nuevo = input(f'{campo.capitalize()} [{actual}]: ').strip()
        if nuevo:
            cambios[campo] = nuevo
    
    mostrar_resultado(*productos.actualizar(id_producto, cambios))
    pausa()
    
def eliminar_producto():
    imprimir_titulo('ELIMINAR PRODUCTO')
    id_producto = pedir_entero('Id: ')
    producto = productos.obtener(id_producto)
    if producto is None:
        imprimir_error('No encontrado')
        return pausa()
    
    imprimir_info(f'Se eliminara: {producto.etiqueta()}')
    if confirmar('confirma?'):
        mostrar_resultado(*productos.eliminar(id_producto))
    else:
        imprimir_info('operacion cancelada')
    pausa()
    
#menu ventas
def registrar_venta():
    imprimir_titulo("REGISTRAR VENTA")
    imprimir_info('Clientes:')
    mostrar_lista(clientes.leer())
    imprimir_info('Productos: ')
    mostrar_lista(productos.leer())
    
    datos = {
        'cliente_id': pedir_entero('\nId del cliente: '),
        'producto_id': pedir_entero('\nId del producto: '),
        'cantidad': pedir_entero('cantidad: ')
    }     
    if None in datos.values():
        imprimir_error('todos los datos deben ser numeros enteros')
        return pausa()
    
    mostrar_resultado(*ventas.crear(datos))
    pausa()
    
def listar_ventas():
    imprimir_titulo('VENTAS')
    mostrar_lista(ventas.leer(), 'todavia no hay ventas')
    pausa()
    
def ver_comprobante():
    imprimir_titulo('COMPROBANTE')
    texto = ventas.comprobante(pedir_entero('Id de la venta: '))
    if texto is None:
        imprimir_error('no existe esa venta')
    else:
        print(texto)
    pausa()

def anular_venta():
    imprimir_titulo('ANULAR VENTA')
    id_venta = pedir_entero('Id de la venta: ')
    if id_venta and confirmar('se devoldera el stock. confirma?'):
        mostrar_resultado(*ventas.eliminar(id_venta))
    else:
        imprimir_info('operacion cancelada')
    pausa()

def resumen():
    imprimir_titulo('RESUMEN')
    print(f' Clientes : {len(clientes.leer())}')
    print(f' Ciudades : {','.join(clientes.ciudades()) or '-'}')
    print(f' Productos : {len(productos.leer())}')
    bajos = productos.con_stock_bajo()
    print(f' Stock bajo: {', '.join(p.nombre for p in bajos) or 'ninguno'}')
    print(f' Ventas : {len(ventas.leer())}')
    print(f' Vendido : ${ventas.total_vendido():.2f}')
    pausa()

# menu completo
MENU_CLIENTES = {
    '1': ('Crear cliente', crear_cliente),
    '2': ('Ver todos', listar_clientes),
    '3': ('Buscar', buscar_cliente),
    '4': ('Ver por id', ver_cliente),
    '5': ('Actualizar', actualizar_cliente),
    '6': ('Eliminar', eliminar_cliente),
    '7': ('Ver por ciudad', cliente_por_ciudad_ejercicio),
    '0': ('Volver', None)
}

MENU_PRODUCTOS = {
    '1': ('Crear producto', crear_producto),
    '2': ('Ver todos', listar_productos),
    '3': ('Buscar', buscar_producto),
    '4': ('Ver por id', ver_producto),
    '5': ('Actualizar', actualizar_producto),
    '6': ('Eliminar', eliminar_producto),
    '0': ('Volver', None)
}

MENU_VENTAS = {
    '1':('Registrar venta', registrar_venta),
    '2':('Ver todas', listar_ventas),
    '3':('Ver comprobante', ver_comprobante),
    '4':('Anular venta', anular_venta),
    '0':('Volver', None)
}

def ejecutar_menu(titulo, opciones):
    '''un solo bucle para los tres submenus'''
    while True:
        imprimir_titulo(titulo)
        for tecla, (texto, _funcion) in opciones.items():
            print(f'    {tecla}. {texto}')
        print()
    
        tecla = input('opcion: ').strip()
        if tecla not in opciones:
            imprimir_error('opcion no valida')
            pausa()
            continue
        
        _texto, funcion = opciones[tecla]
        if funcion is None:
            break
        funcion()

def main():
    while True:
        imprimir_titulo('SISTEMA DE VENTAS')
        print(' 1. clientes')
        print(' 2. productos')
        print(' 3. ventas')
        print(' 4. resumen')
        print(' 0. salir\n')
        
        tecla = input('opcion: '.strip())
        if tecla == '1':
            ejecutar_menu('CLIENTE', MENU_CLIENTES)
        elif tecla == '2':
            ejecutar_menu('PRODUCTO', MENU_PRODUCTOS)
        elif tecla == '3':
            ejecutar_menu('VENTAS', MENU_VENTAS)
        elif tecla == '4':
            resumen()
        elif tecla == '0':
            imprimir_info('¡Hasta luego! 👋')
        else:
            imprimir_error('opcion no valida')
            pausa()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nPrograma interrumpido por el usuario.')
                      