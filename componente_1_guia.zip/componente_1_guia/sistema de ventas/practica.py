from views import ClienteController

#Ejercicio 1 · Quitar duplicados conservando el orden
#Dada ciudades = ["Quito","Guayaquil","Quito","Cuenca","Guayaquil"], 
#obtén una lista sin repetidos respetando el orden de aparición (un set solo no alcanza).

def ejercicio_1(ciudades):
    vistas = set()
    nueva_lista = []
    
    for ciudad in ciudades:
        if ciudad not in vistas:
            vistas.add(ciudad)
            nueva_lista.append(ciudad)
    
    print(nueva_lista)


#Ejercicio 2 · Contar con un diccionario
#Con la misma lista, arma un diccionario {"Quito": 2, "Guayaquil": 2, "Cuenca": 1}.
def ejercicio_2(ciudades):
    nuevo_dic = {}
    
    for ciudad in ciudades:
        if ciudad not in nuevo_dic:
            nuevo_dic[ciudad] = 1
        else:
            nuevo_dic[ciudad] += 1
    
    print(nuevo_dic)
    
def ejercicio_2_corregido(ciudades):
    conteo = {}
    for ciudad in ciudades:
        conteo[ciudad] = conteo.get(ciudad, 0) + 1

    print(conteo)
    
    mas_repetido = max(conteo, key=conteo.get)
    print(mas_repetido)


#Ejercicio 3 · Conjuntos en acción
#inscritos_matematica = {"Ana","Luis","Sol","Marco"} 
# y inscritos_ingles = {"Luis","Marco","Ruth"}. 
# Responde con código: ¿quiénes están en las dos?, 
# ¿quiénes solo en matemática?, 
# ¿cuántos estudiantes distintos hay en total?

def ejercicio_3():
    inscritos_matematica = {"Ana","Luis","Sol","Marco"} 
    inscritos_ingles = {"Luis","Marco","Ruth"}
    
    print(inscritos_matematica & inscritos_ingles)
    print(inscritos_matematica - inscritos_ingles)
    print(len(inscritos_ingles | inscritos_matematica))


#Ejercicio 4 · De lista de diccionarios a índice
#Con clientes = [{"id":1,"nombre":"Ana"},{"id":2,"nombre":"Luis"}], 
#crea un diccionario {id: cliente} para acceder por id sin recorrer la lista. 
# Luego imprime el nombre del id 2.
def ejercicio_4(clientes):
    dic_cliente = {}
    
    for cliente in range(len(clientes)):
        dic_cliente[cliente + 1] = clientes[cliente]
    
    print(dic_cliente[2]['nombre'])

def ejercicio_4_corregido(clientes):
    indice = {cliente['id']: cliente for cliente in clientes}
    print(indice[2]['nombre'])

#Ejercicio 5 · Tuplas como registros inmutables
#Dada ventas = [("enero", 1500), ("febrero", 1800), ("marzo", 1200)], 
# imprime el mes con mayor venta y el total, 
# usando desempaquetado de tuplas.
def ejercicio_5(ventas):
    mayor_precio = 0
    mayor_mes = ''
    
    for i in ventas:
        mes, total = i[0], i[1]
        if total > mayor_precio:
            mayor_precio = total
            mayor_mes = mes
    
    print(f'mayor venta: {mayor_mes}: {mayor_precio}')

def ejercicio_5_corregido(ventas):
    total = sum(monto for _mes, monto in ventas)
    
    mejor_mes, mejor_monto = max(ventas, key=lambda venta: venta[1])
    
    print(f'Total: {total}')
    print(f'Mejor mes: {mejor_mes} con {mejor_monto}')
    
    for mes, monto in ventas:
        print(f'{mes:<10} {monto}')
   
   
# Ejercicio 6 · Sobre el proyecto
# Agrega al Controlador la función clientes_por_ciudad() 
# que devuelva un diccionario 
# {"Guayaquil": ["Ana", "Luis"], "Quito": ["Sol"]}. 
def ejercicio_6():
    diccionario = ClienteController()
    print(diccionario.cliente_por_ciudad())
    
# Ejercicio 7 · ¿Instancia, de clase o estático?
#Clasifica cada método y justifica: (a) calcular el total de una venta, 
# (b) crear un objeto Producto a partir de un diccionario, 
# (c) saber si un precio es válido, (d) saber si un producto tiene stock bajo, 
# (e) calcular el IVA de cualquier monto.

# Ejercicio 8 · Un modelo nuevo con herencia
# Agrega la clase Proveedor, que hereda de Persona 
# y suma ruc y empresa. Escribe __init__, 
# a_diccionario() y etiqueta() reutilizando al padre.


ciudades = ["Quito","Guayaquil","Quito","Cuenca","Guayaquil"]
#ejercicio_1(ciudades)

#ejercicio_2(ciudades)
#ejercicio_2_corregido(ciudades)

#ejercicio_3()

clientes = [{"id":1,"nombre":"Ana"},{"id":2,"nombre":"Luis"}]
# ejercicio_4(clientes)
# ejercicio_4_corregido(clientes)

ventas = [("enero", 1500), ("febrero", 1800), ("marzo", 1200)]
#ejercicio_5(ventas)
#ejercicio_5_corregido(ventas)

#ejercicio_6()

