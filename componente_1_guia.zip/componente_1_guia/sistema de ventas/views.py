from abc import ABC, abstractmethod

from models import Cliente, Producto, Venta
from shared.json_manage import GestorJSON
from shared.herramientas import es_email_valido

class CrudBase(ABC):
    @abstractmethod
    def leer(self):
        pass
    
    @abstractmethod
    def obtener(self, id_registro):
        pass
    
    @abstractmethod
    def buscar(self, texto):
        pass
    
    @abstractmethod
    def siguiente(self):
        pass
    
    @abstractmethod
    def crear(self, datos):
        pass
    
    @abstractmethod
    def actualizar(self, id_registro, datos):
        pass
    
    @abstractmethod
    def eliminar(self, id_registro):
        pass

class ClienteController(CrudBase):
    def __init__(self, archivo='data/clientes.json'):
        self.gestor = GestorJSON(archivo)
        
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Cliente.desde_diccionario(datos))
    
    def guardar(self):
        datos = []
        for cliente in self.lista:
            datos.append(cliente.a_diccionario())
        self.gestor.guardar(datos)
    
    def validar(self, datos, id_actual=None):
        if id_actual is None:
            for campo in ('nombre', 'apellido', 'email'):
                if str(datos.get(campo, '')).strip() == '':
                    return f'el campo {campo} es obligatorio'
        
        if 'email' in datos:
            email = str(datos['email']).strip().lower()
            if not es_email_valido(email):
                return f"Email invalido: '{email}'"   
            
            usados = {c.email for c in self.lista if c.id != id_actual}
            if email in usados:
                return 'Ese email ya esta registrado'
            
        telefono = str(datos.get('telefono', '')).strip()
        if telefono != '' and not telefono.isdigit():
            return 'el telefono solo puede tener numeros'
        return None
    
    def leer(self):
        return self.lista
    
    def obtener(self, id_cliente):
        for cliente in self.lista:
            if cliente.id == id_cliente:
                return cliente
        return None
    
    def buscar(self, texto):
        texto = texto.strip().lower()
        encontrados = []
        if texto == '':
            return encontrados
        
        for cliente in self.lista:
            if (texto in cliente.nombre.lower()
                or texto in cliente.apellido.lower()
                or texto in cliente.email
                or texto in cliente.telefono
                or texto in cliente.ciudad.lower()
                ):
                encontrados.append(cliente)
        return encontrados
    
    def siguiente(self):
        mayor = 0
        for cliente in self.lista:
            if cliente.id > mayor:
                mayor = cliente.id
        return mayor + 1
    
    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error
        
        cliente = Cliente(self.siguiente(),
                          str(datos['nombre']).strip().title(),
                          str(datos['apellido']).strip().title(),
                          str(datos['email']).strip().lower(),
                          str(datos.get('telefono', '')).strip(),
                          str(datos.get('ciudad', '')).strip().title())
        self.lista.append(cliente)
        self.guardar()
        return True, f'cliente creado: {cliente.etiqueta()}'
    
    def actualizar(self, id_cliente, datos):
        cliente = self.obtener(id_cliente)
        if cliente in None:
            return False, f'No existe un cliente con id {id_cliente}'
        
        if not datos:
            return False, 'No se indico nungun cambio'
        
        permitidos = {'nombre', 'apellido', 'email', 'ciudad'}
        desconocidos = set(datos) - permitidos
        if desconocidos:
            return False, f'campos no validos: {', '.join(sorted(desconocidos))}'
        
        error = self.validar(datos, id_cliente)
        if error:
            return False, error
        
        for campo, valor in datos.items():
            valor = str(valor).strip()
            if campo in ('nombre', 'apellido', 'ciudad'):
                valor = valor.title()
            elif campo == 'email':
                valor = valor.lower()
            setattr(cliente, campo, valor)
        
        self.guardar()
        return True, f'cliente {id_cliente} actualizado'

    def eliminar(self, id_cliente):
        cliente = self.obtener(id_cliente)
        if cliente in None:
            return False, f'no existe un cliente con id {id_cliente}'
        
        self.lista.remove(cliente)
        self.guardar()
        return True, f'cliente {id_cliente} eliminado'
    
    def ciudades(self):
        return sorted({c.ciudad for c in self.lista if c.ciudad != ''})
    
    #agregado por ejercicio 6
    def cliente_por_ciudad(self):
        agrupados = {}
        for registro in self.gestor.leer():
            ciudad = registro.get('ciudad', '').title() or 'sin ciudad'
            
            agrupados.setdefault(ciudad, []).append(registro['nombre'])
        return agrupados

# controlador de productos
class ProductoController(CrudBase):
    def __init__(self, archivo = 'data/productos.json'):
        self.gestor = GestorJSON(archivo)
        
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Producto.desde_diccionario(datos))
        
    def guardar(self):
        datos =[]
        for producto in self.lista:
            datos.append(producto.a_diccionario())
        self.gestor.guardar(datos)
    
    def validar(self, datos, id_actual = None):
        if id_actual is None:
            for campo in ('nombre', 'precio'):
                if str(datos.get(campo, '')).strip() == '':
                    return f'El campo {campo} es obligatorio'
        
        if 'precio' in datos and not Producto.es_precio_valido(datos['precio']):
            return f"precio invalido: '{datos['precio']}' (debe ser numero mayor a 0)"
        
        stock = str(datos.get('stock', '')).strip()
        if stock != '' and not stock.isdigit():
            return 'el stock debe ser numero entero positivo'
        
        if 'nombre' in datos:
            nombre = str(datos['nombre']).strip().title()
            for otro in self.lista:
                if otro.nombre == nombre and otro.id != id_actual:
                    return f'ya existe un producto llamado {nombre}'
        
        return None
    
    def leer(self):
        return self.lista
    
    def obtener(self, id_producto):
        for producto in self.lista:
            if producto.id == id_producto:
                return producto
        return None
    
    def buscar(self, texto):
        texto = texto.strip().lower()
        encontrados = []
        if texto == '':
            return encontrados
        
        for producto in self.lista:
            if texto in producto.nombre.lower():
                encontrados.append(producto)
        return encontrados
    
    def siguiente(self):
        mayor = 0
        for producto in self.lista:
            if producto.id > mayor:
                mayor = producto.id
        return mayor + 1
    
    def crear(self, datos):
        error = self.validar(datos)
        if error:
           return False, error
        
        stock = str(datos.get('stock', '')).strip()
        producto = Producto(self.siguiente(),
                            str(datos['nombre']).strip().lower(),
                            float(datos['precio']),
                            int(stock) if stock != '' else 0)
        
        self.lista.append(producto)
        self.guardar()
        return True, f'producto creado: {producto.etiqueta()}'
    
    def actualizar(self, id_producto, datos):
        producto = self.obtener(id_producto)
        if producto is None:
            return False, f'no existe un producto con id {id_producto}'
        
        if not datos:
            return False, 'no se indico ningun cambio'
        
        desconocidos = set(datos) - {'nombre', 'precio', 'stock'}
        if desconocidos:
            return False, f'campo no validos: {','.join(sorted(desconocidos))}'
        
        error = self.validar(datos, id_producto)
        if error:
            return False, error
        
        if 'nombre' in datos:
            producto.nombre = str(datos['nombre']).strip().title()
        if 'precio' in datos:
            producto.precio = float(datos['precio'])
        if 'stock' in datos:
            producto.stock = int(datos['stock'])
        
        self.guardar()
        return True, f'producto {id_producto} actulizado'
    
    def eliminar(self, id_producto):
        producto = self.obtener(id_producto)
        if producto is None:
            return False, f'no existe un producto con id {id_producto}'
        
        self.lista.remove(producto)
        self.guardar()
        return True, f'producto {id_producto} eliminado'
    
    def con_stock_bajo(self):
        bajo = []
        for producto in self.lista:
            if producto.stock_bajo():
                bajo.append(producto)
        return bajo

# controlador ventas
class VentaController(CrudBase):
    def __init__(self, clientes, productos, archivo= 'data/ventas.json'):
        self.clientes = clientes
        self.productos = productos
        self.gestor = GestorJSON(archivo)
        
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Venta.desde_diccionario(datos))
        
    def guardar(self):
        datos = []
        for venta in self.lista:
            datos.append(venta.a_diccionario())
        self.gestor.guardar(datos)
    
    def validar(self, datos):
        try:
            cliente_id = int(datos.get('cliente_id', 0))
            producto_id = int(datos.get('producto_id', 0))
            cantidad = int(datos.get('cantidad', 0))
        except (TypeError, ValueError):
            return 'cliente_id, producto_id y cantidad deben ser numeros enteros'
        
        if cantidad <= 0:
            return 'la cantidad debe ser mayor a 0'
        if self.clientes.obtener(cliente_id) is None:
            return f'no existe un cliente con id {cliente_id}'
        
        producto = self.productos.obtener(producto_id)
        if producto is None:
            return f'no existe un producto con id {producto_id}'
        if not producto.hay_stock(cantidad):
            return (f'stock insuficiente de {producto.nombre}: '
                    f'hay {producto.stock}, piden {cantidad}')
        
        return None
    
    def leer(self):
        return self.lista
    
    def obtener(self, id_venta):
        for venta in self.lista:
            if venta.id == id_venta:
                return venta
        return None
    
    def buscar(self, texto):
        texto = texto.strip()
        encontradas = []
        if texto == '':
            return encontradas
        
        for venta in self.lista:
            if texto in venta.fecha:
                encontradas.append(venta)
        return encontradas
    
    def siguiente(self):
        mayor = 0
        for venta in self.lista:
            if venta.id > mayor:
                mayor = venta.id
        return mayor + 1
    
    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error
        
        producto = self.productos.obtener(int(datos['producto_id']))
        venta = Venta(self.siguiente(),
                      int(datos['cliente_id']),
                      producto.id,
                      int(datos['cantidad']),
                      producto.precio)
        
        producto.descontar_stock(venta.cantidad)
        self.productos.guardar()
        self.lista.append(venta)
        self.guardar()
        return True, f'venta {venta.id} registrada por ${venta.calcular_total():.2f}'
    
    def actualizar(self, id_venta, datos):
        return False, 'las ventas no se pueden modificar: anulela y regristre otra'
    
    def eliminar(self, id_venta):
        '''anular una venta: se borra y el stock vuelve al producto'''
        venta = self.obtener(id_venta)
        if venta is None:
            return False, f'no existe la venta {id_venta}'
        
        producto = self.productos.obtener(venta.producto_id)
        if producto is not None:
            producto.devolver_stock(venta.cantidad)
            self.productos.guardar()
        
        self.lista.remove(venta)
        self.guardar()
        return True, f'venta {id_venta} anulada y stock devuelto'
    
    def comprobante(self, id_venta):
        venta = self.obtener(id_venta)
        if venta is None:
            return None
        
        cliente = self.clientes.obtener(venta.cliente_id)
        producto = self.productos.obtener(venta.producto_id)
        total = venta.calcular_total()
        
        texto = f'COMPROBANTE #{venta.id}  fecha: {venta.fecha}\n'
        texto += f'cliente: {cliente.nombre_completo() if cliente else 'eliminado'}\n'
        texto += f'producto: {producto.nombre if producto else 'eliminado'}\n'
        texto += f'cantidad: {venta.cantidad} x ${venta.precio_unitario:.2f}\n'
        texto += '-' * 42 + '\n'
        texto += f'SUBTOTAL: ${total:.2f}\n'
        texto += f'TOTAL con IVA: ${Producto.con_iva(total):.2f}'
        return texto
    
    def ventas_por_cliente(self):
        '''DICCIONARIO de LISTAS: {cliente_id: [venta de ese cliente]}'''
        agrupadas = {}
        for venta in self.lista:
            if venta.cliente_id not in agrupadas:
                agrupadas[venta.cliente_id] = []
            agrupadas[venta.cliente_id].append(venta)
        return agrupadas
    
    def total_vendido(self):
        total = 0
        for venta in self.lista:
            total += venta.calcular_total()
            self.gestor
        return round(total, 2)
    
