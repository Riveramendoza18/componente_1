"""Ejercicios de la guía: colecciones (sección 13) y POO (sección 15)."""

# ---------- Ejercicio 1 · Quitar duplicados conservando el orden ----------
ciudades = ["Quito", "Guayaquil", "Quito", "Cuenca", "Guayaquil"]

vistas = set()      # CONJUNTO de control: pregunta rápida "¿ya apareció?"
unicas = []         # LISTA de resultado: conserva el orden
for ciudad in ciudades:
    if ciudad not in vistas:
        vistas.add(ciudad)
        unicas.append(ciudad)
print("Ejercicio 1:", unicas)

# ---------- Ejercicio 2 · Contar con un diccionario ----------
conteo = {}
for ciudad in ciudades:
    conteo[ciudad] = conteo.get(ciudad, 0) + 1     # .get evita el KeyError la primera vez
mas_repetida = max(conteo, key=conteo.get)
print("Ejercicio 2:", conteo, "| más repetida:", mas_repetida)

# ---------- Ejercicio 3 · Conjuntos en acción ----------
inscritos_matematica = {"Ana", "Luis", "Sol", "Marco"}
inscritos_ingles = {"Luis", "Marco", "Ruth"}
ambas = inscritos_matematica & inscritos_ingles         # intersección
solo_mate = inscritos_matematica - inscritos_ingles     # diferencia
total = len(inscritos_matematica | inscritos_ingles)    # unión
print("Ejercicio 3:", sorted(ambas), sorted(solo_mate), total)

# ---------- Ejercicio 4 · De lista de diccionarios a índice ----------
clientes = [{"id": 1, "nombre": "Ana"}, {"id": 2, "nombre": "Luis"}]
indice = {cliente["id"]: cliente for cliente in clientes}
print("Ejercicio 4:", indice[2]["nombre"])   # una sola operación, sin recorrer la lista

# ---------- Ejercicio 5 · Tuplas como registros inmutables ----------
ventas = [("enero", 1500), ("febrero", 1800), ("marzo", 1200)]
total_ventas = sum(monto for _mes, monto in ventas)
mejor_mes, mejor_monto = max(ventas, key=lambda venta: venta[1])
print(f"Ejercicio 5: total {total_ventas} | mejor mes: {mejor_mes} con {mejor_monto}")
for mes, monto in ventas:                    # desempaquetado en el for
    print(f"   {mes:<10} {monto}")

# El ejercicio 6 (clientes_por_ciudad) está dentro de proyecto_clientes/views.py, opción 8 del menú.

# ---------- Ejercicio 7 · ¿Instancia, de clase o estático? ----------
# Las clases Producto, Venta, Persona y Cliente se definen UNA sola vez aquí abajo,
# y los ejercicios 8, 9 y 10 les van sumando cosas (así no se pisan entre sí).
#
# (a) Total de una venta            -> DE INSTANCIA: depende de los items de ESA venta (self).
# (b) Producto desde un diccionario -> DE CLASE: aún no hay objeto, lo fabrica cls(...).
# (c) ¿Precio válido?               -> ESTÁTICO: no usa ni self ni cls.
# (d) ¿Stock bajo?                  -> DE INSTANCIA: compara self.stock.
# (e) IVA de cualquier monto        -> ESTÁTICO: recibe un monto cualquiera.

class Producto:
    IVA = 0.15                   # Ecuador
    DESCUENTO_MAYORISTA = 0.10   # Ejercicio 10: atributo estático nuevo

    def __init__(self, nombre, precio, stock):
        self.nombre = nombre
        self.precio = precio
        self.stock = stock

    # (b) De clase: constructor alternativo
    @classmethod
    def desde_diccionario(cls, datos):
        return cls(datos["nombre"], datos["precio"], datos["stock"])

    # (c) Estático: no usa self ni cls
    @staticmethod
    def precio_valido(precio):
        return isinstance(precio, (int, float)) and precio > 0

    # (d) De instancia: usa self.stock
    def tiene_stock_bajo(self, minimo=5):
        return self.stock < minimo

    # (e) Estático: monto cualquiera
    @staticmethod
    def calcular_iva(monto, tasa=0.15):
        return monto * tasa

    # Ejercicio 10: estático, aplica el descuento solo desde 12 unidades
    @staticmethod
    def precio_mayorista(precio, cantidad):
        if cantidad >= 12:
            return precio * (1 - Producto.DESCUENTO_MAYORISTA)
        return precio

    # Ejercicio 9: cada clase sabe describirse
    def describir(self):
        return f"{self.nombre} a ${self.precio}"


class Venta:
    def __init__(self):
        self.items = []  # lista de (Producto, cantidad)

    def agregar(self, producto, cantidad):
        self.items.append((producto, cantidad))

    # (a) De instancia: depende de los items de esta venta
    def calcular_total(self):
        return sum(p.precio * c for p, c in self.items)

    # Ejercicio 9
    def describir(self):
        unidades = sum(c for _p, c in self.items)
        return f"venta de {unidades} unidades"


# Pruebas del ejercicio 7
leche = Producto.desde_diccionario({"nombre": "Leche", "precio": 1.20, "stock": 3})   # (b)
venta = Venta()
venta.agregar(leche, 2)
venta.agregar(Producto("Arroz", 2.00, 50), 4)
print("Ejercicio 7:")
print("   (a) total de la venta:", venta.calcular_total())
print("   (b) producto desde dict:", leche.nombre)
print("   (c) precio_valido(-5):", Producto.precio_valido(-5))
print("   (d) stock bajo de la leche:", leche.tiene_stock_bajo())
print("   (e) IVA de 100:", Producto.calcular_iva(100))


# ---------- Ejercicio 8 · Un modelo nuevo con herencia ----------
class Persona:
    def __init__(self, nombre, correo):
        self.nombre = nombre
        self.correo = correo

    def a_diccionario(self):
        return {"nombre": self.nombre, "correo": self.correo}

    def etiqueta(self):
        return f"{self.nombre} <{self.correo}>"

    def describir(self):                 # Ejercicio 9: delega en etiqueta()
        return self.etiqueta()


class Proveedor(Persona):
    def __init__(self, nombre, correo, ruc, empresa):
        super().__init__(nombre, correo)     # el padre guarda nombre y correo
        self.ruc = ruc
        self.empresa = empresa

    def a_diccionario(self):
        datos = super().a_diccionario()      # parte del diccionario del padre
        datos["ruc"] = self.ruc
        datos["empresa"] = self.empresa
        return datos

    def etiqueta(self):
        return f"{super().etiqueta()} - {self.empresa} (RUC {self.ruc})"


proveedor = Proveedor("Ana Mora", "ana@lacteos.ec", "0912345678001", "Lácteos del Litoral")
print("Ejercicio 8:", proveedor.a_diccionario())
print("            ", proveedor.etiqueta())


# ---------- Ejercicio 9 · Polimorfismo sin if ----------
class Cliente:
    def __init__(self, nombre, apellido, ciudad):
        self.nombre = nombre
        self.apellido = apellido
        self.ciudad = ciudad

    def describir(self):
        return f"{self.nombre} {self.apellido} de {self.ciudad}"


def describir(objeto):
    # Sin if y sin parámetro "tipo": cada clase ya sabe describirse
    return objeto.describir()


print("Ejercicio 9:")
for objeto in (Cliente("Ana", "Pérez", "Quito"), leche, venta, proveedor):
    print("  ", describir(objeto))


# ---------- Ejercicio 10 · Atributo estático nuevo ----------
def comprobante(producto, cantidad):
    precio_final = Producto.precio_mayorista(producto.precio, cantidad)
    total = precio_final * cantidad
    print("\n--- COMPROBANTE ---")
    print("Producto:", producto.nombre)
    print("Precio unitario:", producto.precio)
    print("Cantidad:", cantidad)
    print("Precio con descuento:", round(precio_final, 2))
    print("Total a pagar:", round(total, 2))


print("Ejercicio 10:")
comprobante(Producto("Arroz", 2.00, 100), 5)    # menos de 12: sin descuento
comprobante(Producto("Arroz", 2.00, 100), 12)   # 12 o más: 10 % de descuento
