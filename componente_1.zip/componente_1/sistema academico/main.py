from shared.herramientas import (imprimir_titulo, imprimir_exito, imprimir_error,
                                 imprimir_info, confirmar)
from views import EstudiantesController, MateriaController, MatriculaController

estudiantes = EstudiantesController()
materias = MateriaController()
matriculas = MatriculaController(estudiantes, materias)


def pausa():
    input('\nPresione Enter para continuar...')


def pedir_entero(etiqueta):
    """Devuelve un entero o None si el usuario escribió otra cosa."""
    try:
        return int(input(etiqueta))
    except ValueError:
        return None


def mostrar_resultado(exito, mensaje):
    if exito:
        imprimir_exito(mensaje)
    else:
        imprimir_error(mensaje)


def mostrar_lista(objetos, vacio='No hay registros todavía.'):
    """Sirve para estudiantes, materias y matrículas: cada modelo sabe mostrarse."""
    if not objetos:
        imprimir_info(vacio)
        return
    for objeto in objetos:
        print(f'  {objeto}')
    imprimir_info(f'Total: {len(objetos)}')


def mostrar_detalle(objeto):
    for clave, valor in objeto.a_diccionario().items():
        nombre = str(clave).replace('_', ' ').capitalize()
        print(f'  {nombre:<16}: {valor}')


# ---------------------------------------------------------------- estudiantes
def crear_estudiante():
    imprimir_titulo('CREAR ESTUDIANTE')
    datos = {
        'nombre': input('Nombre: '),
        'apellido': input('Apellido: '),
        'email': input('Email: '),
        'carnet': input('Carnet (ej. EST2026001): '),
        'carrera': input('Carrera: '),
    }
    mostrar_resultado(*estudiantes.crear(datos))
    pausa()


def listar_estudiantes():
    imprimir_titulo('ESTUDIANTES')
    mostrar_lista(estudiantes.leer(), 'Todavía no hay estudiantes.')
    pausa()


def buscar_estudiantes():
    imprimir_titulo('BUSCAR ESTUDIANTES')
    termino = input('Nombre, apellido, email, carnet o carrera: ')
    mostrar_lista(estudiantes.buscar(termino), f"Ningún estudiante coincide con '{termino}'.")
    pausa()


def ver_estudiante():
    imprimir_titulo('VER ESTUDIANTE POR ID')
    estudiante = estudiantes.obtener(pedir_entero('Id: '))
    if estudiante is None:
        imprimir_error('No encontrado')
    else:
        mostrar_detalle(estudiante)
    pausa()


def actualizar_estudiante():
    imprimir_titulo('ACTUALIZAR ESTUDIANTE')
    id_est = pedir_entero('Id: ')
    estudiante = estudiantes.obtener(id_est)
    if estudiante is None:
        imprimir_error('No encontrado')
        return pausa()

    imprimir_info(f'Editando: {estudiante.etiqueta()}')
    print('Deje en blanco lo que no quiera cambiar.\n')

    cambios = {}
    for campo in ('nombre', 'apellido', 'email', 'carnet', 'carrera'):
        nuevo = input(f'{campo.capitalize()} [{getattr(estudiante, campo)}]: ').strip()
        if nuevo:
            cambios[campo] = nuevo

    mostrar_resultado(*estudiantes.actualizar(id_est, cambios))
    pausa()


def eliminar_estudiante():
    imprimir_titulo('ELIMINAR ESTUDIANTE')
    id_est = pedir_entero('Id: ')
    estudiante = estudiantes.obtener(id_est)
    if estudiante is None:
        imprimir_error('No encontrado')
        return pausa()

    imprimir_info(f'Se eliminará: {estudiante.etiqueta()}')
    if confirmar('¿Confirma?'):
        mostrar_resultado(*estudiantes.eliminar(id_est))
    else:
        imprimir_info('Operación cancelada')
    pausa()


# -------------------------------------------------------------------- materias
def crear_materia():
    imprimir_titulo('CREAR MATERIA')
    datos = {
        'nombre': input('Nombre: '),
        'codigo': input('Código (ej. MAT101): '),
        'creditos': input('Créditos (1 a 10): '),
        'cupos': input('Cupos (0 a 30): '),
    }
    mostrar_resultado(*materias.crear(datos))
    pausa()


def listar_materias():
    imprimir_titulo('MATERIAS')
    mostrar_lista(materias.leer(), 'Todavía no hay materias.')
    pausa()


def buscar_materia():
    imprimir_titulo('BUSCAR MATERIA')
    termino = input('Nombre o código: ')
    mostrar_lista(materias.buscar(termino), 'Sin coincidencias.')
    pausa()


def ver_materia():
    imprimir_titulo('VER MATERIA POR ID')
    materia = materias.obtener(pedir_entero('Id: '))
    if materia is None:
        imprimir_error('No encontrada')
    else:
        mostrar_detalle(materia)
    pausa()


def actualizar_materia():
    imprimir_titulo('ACTUALIZAR MATERIA')
    id_mat = pedir_entero('Id: ')
    materia = materias.obtener(id_mat)
    if materia is None:
        imprimir_error('No encontrada')
        return pausa()

    imprimir_info(f'Editando: {materia.etiqueta()}')
    print('Deje en blanco lo que no quiera cambiar.\n')

    cambios = {}
    for campo in ('nombre', 'codigo', 'creditos', 'cupos'):
        nuevo = input(f'{campo.capitalize()} [{getattr(materia, campo)}]: ').strip()
        if nuevo:
            cambios[campo] = nuevo

    mostrar_resultado(*materias.actualizar(id_mat, cambios))
    pausa()


def eliminar_materia():
    imprimir_titulo('ELIMINAR MATERIA')
    id_mat = pedir_entero('Id: ')
    materia = materias.obtener(id_mat)
    if materia is None:
        imprimir_error('No encontrada')
        return pausa()

    imprimir_info(f'Se eliminará: {materia.etiqueta()}')
    if confirmar('¿Confirma?'):
        mostrar_resultado(*materias.eliminar(id_mat))
    else:
        imprimir_info('Operación cancelada')
    pausa()


# ------------------------------------------------------------------ matrículas
def registrar_matricula():
    imprimir_titulo('MATRICULAR')
    imprimir_info('Estudiantes:')
    mostrar_lista(estudiantes.leer())
    imprimir_info('Materias:')
    mostrar_lista(materias.leer())

    datos = {
        'estudiante_id': input('\nId del estudiante: '),
        'materia_id': input('Id de la materia: '),
        'periodo': input('Periodo (ej. 2026-1): '),
        'nota': input('Nota 0-20 (Enter si todavía no tiene): '),
    }
    mostrar_resultado(*matriculas.crear(datos))
    pausa()


def listar_matriculas():
    imprimir_titulo('MATRÍCULAS')
    mostrar_lista(matriculas.leer(), 'Todavía no hay matrículas.')
    pausa()


def registrar_nota():
    imprimir_titulo('REGISTRAR NOTA')
    id_mat = pedir_entero('Id de la matrícula: ')
    if id_mat is None or matriculas.obtener(id_mat) is None:
        imprimir_error('No existe esa matrícula')
        return pausa()
    nota = input('Nota (0 a 20): ')
    mostrar_resultado(*matriculas.registrar_nota(id_mat, nota))
    pausa()


def ver_certificado():
    imprimir_titulo('CERTIFICADO')
    texto = matriculas.certificado(pedir_entero('Id de la matrícula: '))
    if texto is None:
        imprimir_error('No existe esa matrícula')
    else:
        print(texto)
    pausa()


def retirar_matricula():
    imprimir_titulo('RETIRAR MATRÍCULA')
    id_mat = pedir_entero('Id de la matrícula: ')
    if id_mat is not None and confirmar('Se devolverá el cupo a la materia. ¿Confirma?'):
        mostrar_resultado(*matriculas.retirar_matricula(id_mat))
    else:
        imprimir_info('Operación cancelada')
    pausa()


def ver_promedio():
    imprimir_titulo('PROMEDIO DE UN ESTUDIANTE')
    id_est = pedir_entero('Id del estudiante: ')
    estudiante = estudiantes.obtener(id_est)
    if estudiante is None:
        imprimir_error('No encontrado')
        return pausa()

    imprimir_info(estudiante.etiqueta())
    mostrar_lista(matriculas.matriculas_por_estudiante().get(id_est, []),
                  'Este estudiante no tiene matrículas.')
    promedio = matriculas.promedio_de_estudiante(id_est)
    print(f'\n  Promedio: {promedio if promedio is not None else "sin notas"}')
    pausa()


def resumen():
    imprimir_titulo('RESUMEN')
    sin_cupo = materias.materias_sin_cupo()
    print(f'  Estudiantes          : {len(estudiantes.leer())}')
    print(f'  Carreras distintas   : {", ".join(estudiantes.carreras()) or "ninguna"}')
    print(f'  Materias             : {len(materias.leer())}')
    print(f'  Materias sin cupo    : {", ".join(m.nombre for m in sin_cupo) or "ninguna"}')
    print(f'  Matrículas           : {len(matriculas.leer())}')
    print(f'  Matrículas aprobadas : {matriculas.cantidad_aprobadas()}')
    pausa()


# ------------------------------------------------------------------- menús
MENU_ESTUDIANTES = {
    '1': ('Crear estudiante', crear_estudiante),
    '2': ('Ver todos', listar_estudiantes),
    '3': ('Buscar', buscar_estudiantes),
    '4': ('Ver por id', ver_estudiante),
    '5': ('Actualizar', actualizar_estudiante),
    '6': ('Eliminar', eliminar_estudiante),
    '0': ('Volver', None),
}

MENU_MATERIAS = {
    '1': ('Crear materia', crear_materia),
    '2': ('Ver todas', listar_materias),
    '3': ('Buscar', buscar_materia),
    '4': ('Ver por id', ver_materia),
    '5': ('Actualizar', actualizar_materia),
    '6': ('Eliminar', eliminar_materia),
    '0': ('Volver', None),
}

MENU_MATRICULAS = {
    '1': ('Matricular', registrar_matricula),
    '2': ('Ver todas', listar_matriculas),
    '3': ('Registrar nota', registrar_nota),
    '4': ('Ver certificado', ver_certificado),
    '5': ('Retirar matrícula', retirar_matricula),
    '6': ('Promedio de un estudiante', ver_promedio),
    '0': ('Volver', None),
}


def ejecutar_menu(titulo, opciones):
    """Un solo bucle para los tres submenús."""
    while True:
        imprimir_titulo(titulo)
        for tecla, (texto, _funcion) in opciones.items():
            print(f'    {tecla}. {texto}')
        print()

        tecla = input('Opción: ').strip()
        if tecla not in opciones:
            imprimir_error('Opción no válida')
            pausa()
            continue

        _texto, funcion = opciones[tecla]
        if funcion is None:
            break
        funcion()


def main():
    while True:
        imprimir_titulo('SISTEMA ACADÉMICO')
        print('  1. Estudiantes')
        print('  2. Materias')
        print('  3. Matrículas')
        print('  4. Resumen')
        print('  0. Salir\n')

        tecla = input('Opción: ').strip()
        if tecla == '1':
            ejecutar_menu('ESTUDIANTES', MENU_ESTUDIANTES)
        elif tecla == '2':
            ejecutar_menu('MATERIAS', MENU_MATERIAS)
        elif tecla == '3':
            ejecutar_menu('MATRÍCULAS', MENU_MATRICULAS)
        elif tecla == '4':
            resumen()
        elif tecla == '0':
            imprimir_info('¡Hasta luego!')
            break
        else:
            imprimir_error('Opción no válida')
            pausa()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nPrograma interrumpido por el usuario.')
