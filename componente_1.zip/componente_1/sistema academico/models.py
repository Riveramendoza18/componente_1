from datetime import date


class ModeloBase:
    """Clase padre de todos los modelos (no se toca)."""

    def __init__(self, id):
        self.id = id

    @classmethod
    def desde_diccionario(cls, datos):
        datos = dict(datos)
        id_registro = datos.pop('id')
        return cls(id_registro, **datos)

    def a_diccionario(self):
        return {'id': self.id}

    def etiqueta(self):
        return f'registro {self.id}'

    def __str__(self):
        return f'[{self.id}] {self.etiqueta()}'


class Persona(ModeloBase):
    def __init__(self, id, nombre, apellido, email):
        super().__init__(id)
        self.nombre = nombre
        self.apellido = apellido
        self.email = email

    def nombre_completo(self):
        return f'{self.nombre} {self.apellido}'

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos['nombre'] = self.nombre
        datos['apellido'] = self.apellido
        datos['email'] = self.email
        return datos

    def etiqueta(self):
        return self.nombre_completo()


class Estudiante(Persona):
    """Estudiante ES UNA Persona, con carnet y carrera."""

    def __init__(self, id, nombre, apellido, email, carnet='', carrera=''):
        super().__init__(id, nombre, apellido, email)
        self.carnet = carnet
        self.carrera = carrera

    def a_diccionario(self):
        datos = super().a_diccionario()      # id + nombre + apellido + email
        datos['carnet'] = self.carnet
        datos['carrera'] = self.carrera
        return datos

    def etiqueta(self):
        return f'{super().etiqueta()} · {self.carnet} · {self.carrera}'


class Materia(ModeloBase):
    """Aquí va TODO lo estático del proyecto."""

    CUPOS_MAXIMOS = 30          # atributo estático
    NOTA_APROBACION = 14        # atributo estático

    def __init__(self, id, nombre, codigo, creditos=0, cupos=0):
        super().__init__(id)
        self.nombre = nombre
        self.codigo = codigo
        self.creditos = int(creditos)
        self.cupos = int(cupos)

    @staticmethod
    def es_nota_valida(valor):
        """True si es un número entre 0 y 20 (ambos incluidos)."""
        try:
            numero = float(valor)
        except (TypeError, ValueError):
            return False
        return 0 <= numero <= 20

    def hay_cupo(self):
        return self.cupos > 0

    def ocupar_cupo(self):
        self.cupos -= 1

    def liberar_cupo(self):
        self.cupos += 1

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos['nombre'] = self.nombre
        datos['codigo'] = self.codigo
        datos['creditos'] = self.creditos
        datos['cupos'] = self.cupos
        return datos

    def etiqueta(self):
        aviso = '' if self.hay_cupo() else ' ⚠ sin cupo'
        return (f'{self.nombre} · {self.codigo} · {self.creditos} créditos · '
                f'cupos: {self.cupos}{aviso}')


class Matricula(ModeloBase):
    """Une un estudiante con una materia (relación por id, NO herencia)."""

    def __init__(self, id, estudiante_id, materia_id, periodo, nota=None, fecha=''):
        super().__init__(id)
        self.estudiante_id = int(estudiante_id)
        self.materia_id = int(materia_id)
        self.periodo = periodo
        # nota=None significa "todavía sin calificar"
        self.nota = None if nota in (None, '') else float(nota)
        self.fecha = fecha or date.today().isoformat()

    def esta_aprobada(self):
        return self.nota is not None and self.nota >= Materia.NOTA_APROBACION

    def estado(self):
        """Se calcula, no se guarda."""
        if self.nota is None:
            return 'Sin nota'
        return 'Aprobado' if self.esta_aprobada() else 'Reprobado'

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos['estudiante_id'] = self.estudiante_id
        datos['materia_id'] = self.materia_id
        datos['periodo'] = self.periodo
        datos['nota'] = self.nota
        datos['fecha'] = self.fecha
        return datos

    def etiqueta(self):
        nota = 'sin nota' if self.nota is None else self.nota
        return (f'{self.fecha} · estudiante {self.estudiante_id} · '
                f'materia {self.materia_id} · periodo {self.periodo} · '
                f'nota: {nota} ({self.estado()})')
