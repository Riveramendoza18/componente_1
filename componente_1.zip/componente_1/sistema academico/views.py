from abc import ABC, abstractmethod

from models import Estudiante, Materia, Matricula
from shared.json_manage import GestorJSON
from shared.herramientas import es_email_valido


def a_entero(valor):
    """Convierte a int o devuelve None si no se puede (sin lanzar errores)."""
    try:
        return int(str(valor).strip())
    except (TypeError, ValueError):
        return None


class CrudBase(ABC):
    @abstractmethod
    def leer(self):
        pass

    @abstractmethod
    def obtener(self, id_registro):
        pass

    @abstractmethod
    def buscar(self, texto):
        pass

    @abstractmethod
    def siguiente(self):
        pass

    @abstractmethod
    def crear(self, datos):
        pass

    @abstractmethod
    def actualizar(self, id_registro, datos):
        pass

    @abstractmethod
    def eliminar(self, id_registro):
        pass


# ======================================================================
#  ESTUDIANTES
# ======================================================================
class EstudiantesController(CrudBase):
    # TUPLA: los campos buscables no cambian nunca, por eso es inmutable.
    CAMPOS_BUSCABLES = ('nombre', 'apellido', 'email', 'carnet', 'carrera')
    OBLIGATORIOS = ('nombre', 'apellido', 'email', 'carnet')

    def __init__(self, archivo='data/estudiantes.json'):
        self.gestor = GestorJSON(archivo)
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Estudiante.desde_diccionario(datos))

    def guardar(self):
        self.gestor.guardar([e.a_diccionario() for e in self.lista])

    # ---- conjuntos ----
    def carnets_registrados(self, excepto_id=None):
        """CONJUNTO de carnets usados: preguntar 'x in conjunto' es instantáneo
        y el conjunto no admite repetidos."""
        return {e.carnet.upper() for e in self.lista if e.id != excepto_id}

    def emails_registrados(self, excepto_id=None):
        """CONJUNTO de emails usados (misma razón que el de carnets)."""
        return {e.email.lower() for e in self.lista if e.id != excepto_id}

    def ids_registrados(self):
        """CONJUNTO de ids: sirve para saber si un estudiante existe."""
        return {e.id for e in self.lista}

    def carreras(self):
        """CONJUNTO para quitar carreras repetidas; sorted() lo devuelve ordenado."""
        return sorted({e.carrera for e in self.lista if e.carrera})

    # ---- validación: devuelve un mensaje de error o None ----
    def validar(self, datos, id_actual=None):
        for campo in self.OBLIGATORIOS:
            if id_actual is None or campo in datos:
                if str(datos.get(campo, '')).strip() == '':
                    return f'El campo {campo} es obligatorio'

        if 'email' in datos:
            email = str(datos['email']).strip().lower()
            if not es_email_valido(email):
                return f'Email inválido: {email}'
            if email in self.emails_registrados(id_actual):
                return 'Ese email ya está registrado'

        if 'carnet' in datos:
            carnet = str(datos['carnet']).strip().upper()
            if carnet in self.carnets_registrados(id_actual):
                return 'Ese carnet ya está registrado'
        return None

    # ---- CRUD ----
    def leer(self):
        return self.lista

    def obtener(self, id_estudiante):
        for estudiante in self.lista:
            if estudiante.id == id_estudiante:
                return estudiante
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        encontrados = []
        if texto == '':
            return encontrados
        for estudiante in self.lista:
            for campo in self.CAMPOS_BUSCABLES:
                if texto in str(getattr(estudiante, campo)).lower():
                    encontrados.append(estudiante)
                    break
        return encontrados

    def siguiente(self):
        mayor = 0
        for estudiante in self.lista:
            if estudiante.id > mayor:
                mayor = estudiante.id
        return mayor + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        estudiante = Estudiante(self.siguiente(),
                                str(datos['nombre']).strip().title(),
                                str(datos['apellido']).strip().title(),
                                str(datos['email']).strip().lower(),
                                str(datos['carnet']).strip().upper(),
                                str(datos.get('carrera', '')).strip().title())
        self.lista.append(estudiante)
        self.guardar()
        return True, f'Estudiante creado: {estudiante.etiqueta()}'

    def actualizar(self, id_estudiante, datos):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None:
            return False, f'No existe un estudiante con id {id_estudiante}'
        if not datos:
            return False, 'No se indicó ningún cambio'

        permitidos = {'nombre', 'apellido', 'email', 'carnet', 'carrera'}
        desconocidos = set(datos) - permitidos
        if desconocidos:
            return False, 'Campos no válidos: ' + ', '.join(sorted(desconocidos))

        error = self.validar(datos, id_estudiante)
        if error:
            return False, error

        for campo, valor in datos.items():
            valor = str(valor).strip()
            if campo in ('nombre', 'apellido', 'carrera'):
                valor = valor.title()
            elif campo == 'email':
                valor = valor.lower()
            elif campo == 'carnet':
                valor = valor.upper()
            setattr(estudiante, campo, valor)

        self.guardar()
        return True, f'Estudiante {id_estudiante} actualizado'

    def eliminar(self, id_estudiante):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None:
            return False, f'No existe un estudiante con id {id_estudiante}'
        self.lista.remove(estudiante)
        self.guardar()
        return True, f'Estudiante {id_estudiante} eliminado'


# ======================================================================
#  MATERIAS
# ======================================================================
class MateriaController(CrudBase):
    CAMPOS_BUSCABLES = ('nombre', 'codigo')   # tupla: no cambia nunca

    def __init__(self, archivo='data/materias.json'):
        self.gestor = GestorJSON(archivo)
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Materia.desde_diccionario(datos))

    def guardar(self):
        self.gestor.guardar([m.a_diccionario() for m in self.lista])

    # ---- conjuntos ----
    def codigos_registrados(self, excepto_id=None):
        """CONJUNTO de códigos usados: comprobar si uno existe es instantáneo."""
        return {m.codigo.upper() for m in self.lista if m.id != excepto_id}

    def ids_registrados(self):
        """CONJUNTO de ids: sirve para saber si una materia existe."""
        return {m.id for m in self.lista}

    # ---- validación ----
    def validar(self, datos, id_actual=None):
        for campo in ('nombre', 'codigo', 'creditos'):
            if id_actual is None or campo in datos:
                if str(datos.get(campo, '')).strip() == '':
                    return f'El campo {campo} es obligatorio'

        if 'creditos' in datos:
            creditos = a_entero(datos['creditos'])
            if creditos is None or not 1 <= creditos <= 10:
                return 'Los créditos deben ser un entero entre 1 y 10'

        if str(datos.get('cupos', '')).strip() != '':
            cupos = a_entero(datos['cupos'])
            if cupos is None or not 0 <= cupos <= Materia.CUPOS_MAXIMOS:
                return f'Los cupos deben ser un entero entre 0 y {Materia.CUPOS_MAXIMOS}'

        if 'codigo' in datos:
            codigo = str(datos['codigo']).strip().upper()
            if codigo in self.codigos_registrados(id_actual):
                return f'Ya existe una materia con el código {codigo}'
        return None

    # ---- CRUD ----
    def leer(self):
        return self.lista

    def obtener(self, id_materia):
        for materia in self.lista:
            if materia.id == id_materia:
                return materia
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        encontradas = []
        if texto == '':
            return encontradas
        for materia in self.lista:
            for campo in self.CAMPOS_BUSCABLES:
                if texto in str(getattr(materia, campo)).lower():
                    encontradas.append(materia)
                    break
        return encontradas

    def siguiente(self):
        mayor = 0
        for materia in self.lista:
            if materia.id > mayor:
                mayor = materia.id
        return mayor + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        cupos = str(datos.get('cupos', '')).strip()
        materia = Materia(self.siguiente(),
                          str(datos['nombre']).strip().title(),
                          str(datos['codigo']).strip().upper(),
                          int(datos['creditos']),
                          int(cupos) if cupos != '' else 0)
        self.lista.append(materia)
        self.guardar()
        return True, f'Materia creada: {materia.etiqueta()}'

    def actualizar(self, id_materia, datos):
        materia = self.obtener(id_materia)
        if materia is None:
            return False, f'No existe una materia con id {id_materia}'
        if not datos:
            return False, 'No se indicó ningún cambio'

        desconocidos = set(datos) - {'nombre', 'codigo', 'creditos', 'cupos'}
        if desconocidos:
            return False, 'Campos no válidos: ' + ', '.join(sorted(desconocidos))

        error = self.validar(datos, id_materia)
        if error:
            return False, error

        if 'nombre' in datos:
            materia.nombre = str(datos['nombre']).strip().title()
        if 'codigo' in datos:
            materia.codigo = str(datos['codigo']).strip().upper()
        if 'creditos' in datos:
            materia.creditos = int(datos['creditos'])
        if 'cupos' in datos:
            materia.cupos = int(datos['cupos'])

        self.guardar()
        return True, f'Materia {id_materia} actualizada'

    def eliminar(self, id_materia):
        materia = self.obtener(id_materia)
        if materia is None:
            return False, f'No existe una materia con id {id_materia}'
        self.lista.remove(materia)
        self.guardar()
        return True, f'Materia {id_materia} eliminada'

    def materias_sin_cupo(self):
        return [m for m in self.lista if not m.hay_cupo()]


# ======================================================================
#  MATRÍCULAS
# ======================================================================
class MatriculaController(CrudBase):
    def __init__(self, estudiantes, materias, archivo='data/matriculas.json'):
        self.estudiantes = estudiantes
        self.materias = materias
        self.gestor = GestorJSON(archivo)
        self.lista = []
        for datos in self.gestor.leer():
            self.lista.append(Matricula.desde_diccionario(datos))

    def guardar(self):
        self.gestor.guardar([m.a_diccionario() for m in self.lista])

    def combinaciones_registradas(self):
        """CONJUNTO de tuplas (estudiante, materia, periodo): una tupla es
        inmutable y se puede meter en un conjunto, así detectamos la
        matrícula repetida comparando los tres datos JUNTOS."""
        return {(m.estudiante_id, m.materia_id, m.periodo) for m in self.lista}

    def validar(self, datos):
        estudiante_id = a_entero(datos.get('estudiante_id'))
        materia_id = a_entero(datos.get('materia_id'))
        if estudiante_id is None or materia_id is None:
            return 'El id del estudiante y el de la materia deben ser números enteros'

        periodo = str(datos.get('periodo', '')).strip()
        if periodo == '':
            return 'El periodo es obligatorio (ej. 2026-1)'

        if estudiante_id not in self.estudiantes.ids_registrados():
            return f'No existe un estudiante con id {estudiante_id}'

        if materia_id not in self.materias.ids_registrados():
            return f'No existe una materia con id {materia_id}'
        materia = self.materias.obtener(materia_id)
        if not materia.hay_cupo():
            return f'No hay cupos disponibles en {materia.nombre}'

        if (estudiante_id, materia_id, periodo) in self.combinaciones_registradas():
            return 'Ese estudiante ya está matriculado en esa materia en ese periodo'

        nota = str(datos.get('nota', '')).strip()
        if nota != '' and not Materia.es_nota_valida(nota):
            return 'La nota debe ser un número entre 0 y 20'
        return None

    # ---- CRUD ----
    def leer(self):
        return self.lista

    def obtener(self, id_matricula):
        for matricula in self.lista:
            if matricula.id == id_matricula:
                return matricula
        return None

    def buscar(self, texto):
        texto = texto.strip()
        encontradas = []
        if texto == '':
            return encontradas
        for matricula in self.lista:
            if texto in matricula.periodo or texto in matricula.fecha:
                encontradas.append(matricula)
        return encontradas

    def siguiente(self):
        mayor = 0
        for matricula in self.lista:
            if matricula.id > mayor:
                mayor = matricula.id
        return mayor + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error:
            return False, error

        materia = self.materias.obtener(int(datos['materia_id']))
        nota = str(datos.get('nota', '')).strip()
        matricula = Matricula(self.siguiente(),
                              int(datos['estudiante_id']),
                              materia.id,
                              str(datos['periodo']).strip(),
                              float(nota) if nota != '' else None)

        materia.ocupar_cupo()
        self.materias.guardar()          # el objeto vive en memoria: hay que guardar
        self.lista.append(matricula)
        self.guardar()
        return True, f'Matrícula {matricula.id} registrada (periodo {matricula.periodo})'

    def actualizar(self, id_matricula, datos):
        return False, 'Las matrículas no se editan: use registrar nota o retire la matrícula'

    def registrar_nota(self, id_matricula, nota):
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return False, f'No existe la matrícula {id_matricula}'
        if not Materia.es_nota_valida(nota):
            return False, 'La nota debe ser un número entre 0 y 20'
        matricula.nota = float(nota)
        self.guardar()
        return True, f'Nota registrada: {matricula.nota} ({matricula.estado()})'

    def eliminar(self, id_matricula):
        """Retirar una matrícula: se borra y el cupo vuelve a la materia."""
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return False, f'No existe la matrícula {id_matricula}'

        materia = self.materias.obtener(matricula.materia_id)
        if materia is not None:
            materia.liberar_cupo()
            self.materias.guardar()

        self.lista.remove(matricula)
        self.guardar()
        return True, f'Matrícula {id_matricula} retirada y cupo liberado'

    def retirar_matricula(self, id_matricula):
        return self.eliminar(id_matricula)

    def certificado(self, id_matricula):
        matricula = self.obtener(id_matricula)
        if matricula is None:
            return None

        # DICCIONARIO ÍNDICE {id: objeto}: encontrar a cada uno por su id
        # sin recorrer la lista completa cada vez.
        estudiantes = {e.id: e for e in self.estudiantes.leer()}
        materias = {m.id: m for m in self.materias.leer()}
        estudiante = estudiantes.get(matricula.estudiante_id)
        materia = materias.get(matricula.materia_id)

        if estudiante:
            quien = f'{estudiante.nombre_completo()}   ({estudiante.carnet})'
        else:
            quien = '(estudiante eliminado)'
        if materia:
            que = f'{materia.nombre}   ({materia.codigo}) · {materia.creditos} créditos'
        else:
            que = '(materia eliminada)'
        nota = 'sin nota' if matricula.nota is None else matricula.nota

        texto = f'CERTIFICADO #{matricula.id}   periodo: {matricula.periodo}\n'
        texto += f'Estudiante: {quien}\n'
        texto += f'Materia   : {que}\n'
        texto += '-' * 42 + '\n'
        texto += f'Nota      : {nota}\n'
        texto += f'Estado    : {matricula.estado()}'
        return texto

    def matriculas_por_estudiante(self):
        """DICCIONARIO DE LISTAS {estudiante_id: [matrículas]}: una clave
        con varios valores; setdefault crea la lista la primera vez."""
        agrupadas = {}
        for matricula in self.lista:
            agrupadas.setdefault(matricula.estudiante_id, []).append(matricula)
        return agrupadas

    def promedio_de_estudiante(self, id_estudiante):
        """Promedio de las notas ya registradas, o None si no tiene ninguna."""
        notas = [m.nota for m in self.matriculas_por_estudiante().get(id_estudiante, [])
                 if m.nota is not None]
        if not notas:
            return None
        return round(sum(notas) / len(notas), 2)

    def cantidad_aprobadas(self):
        return sum(1 for m in self.lista if m.esta_aprobada())
