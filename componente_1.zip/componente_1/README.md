# Trabajo Práctico Experimental 1 · Estructura de Datos

Sistema académico en Python con arquitectura MVC, CRUD, colecciones y JSON.

## Contenido

| Carpeta / archivo | Qué es |
|---|---|
| `proyecto_estudiantes/` | **La tarea (sección 14).** Sistema de estudiantes con notas, promedios y materias. |
| `proyecto_clientes/` | El sistema de clientes de la guía, con el ejercicio 6 (clientes por ciudad) como opción 8. |
| `sistema academico/` | Sistema académico con Estudiantes, Materias y Matrículas (herencia, CRUD, colecciones y JSON). |
| `practica.py` | Ejercicios 1 a 10 de la sección 13 y 15. |

## Cómo ejecutar

Requiere Python 3.8 o superior. No necesita instalar librerías.

```
cd proyecto_estudiantes
python main.py
```

En Mac/Linux usar `python3 main.py`. El archivo `data/estudiantes.json` trae dos estudiantes de ejemplo;
si se borra, el programa lo vuelve a crear vacío.

## Menú del sistema de estudiantes

1. Crear estudiante · 2. Ver todos · 3. Buscar · 4. Ver por id · 5. Actualizar · 6. Eliminar ·
7. Agregar nota · 8. Ver promedio · 9. Materias en común · 10. Estadísticas · 0. Salir

## Sistema académico (`sistema academico/`)

Requiere Python 3.12 o superior (usa comillas anidadas dentro de f-strings en `shared/herramientas.py`).

```
cd "sistema academico"
python main.py
```

La carpeta `data/` trae un estudiante y una materia de ejemplo; si se borra, el programa la vuelve a crear vacía.

### Arquitectura

```
models.py   MODELO       ModeloBase -> Persona -> Estudiante · Materia · Matricula
views.py    CONTROLADOR  CrudBase -> EstudiantesController · MateriaController · MatriculaController
main.py     VISTA        menús, input() y print()
shared/     APOYO        herramientas.py y json_manage.py
data/       estudiantes.json · materias.json · matriculas.json
```

### Menú

- **1. Estudiantes** y **2. Materias**: crear, ver todos, buscar, ver por id, actualizar, eliminar.
- **3. Matrículas**: matricular, ver todas, registrar nota, ver certificado, retirar matrícula, promedio de un estudiante.
- **4. Resumen**: estudiantes, carreras distintas, materias sin cupo y matrículas aprobadas.

### Reglas del negocio

- Estudiante: nombre, apellido, email y carnet obligatorios; email válido y único; carnet único.
- Materia: código único; créditos de 1 a 10; cupos de 0 a `Materia.CUPOS_MAXIMOS` (30).
- Matrícula: el estudiante y la materia deben existir; la materia debe tener cupo; no se repite
  estudiante + materia + periodo; la nota va de 0 a 20 y se aprueba con `Materia.NOTA_APROBACION` (14).
- Matricular resta un cupo; retirar la matrícula lo devuelve.
